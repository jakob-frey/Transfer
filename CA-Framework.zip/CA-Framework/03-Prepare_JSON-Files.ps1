﻿$PSScriptRoot = split-path -parent $MyInvocation.MyCommand.Definition
. "$PSScriptRoot\00-Connect-Graph.ps1"

# Declare output path variable with Path and Filename
$CAGroupTargetIDs = Join-Path -Path "$PSScriptRoot\Group-IDs\" -ChildPath "Conditional_Access_Framework_Groups_w_ID_Target.csv"
$CAGroupSourceIDs = Join-Path -Path "$PSScriptRoot\Group-IDs\" -ChildPath "Conditional_Access_Framework_Groups_w_ID_Source.csv"

$MasterJsonFilesPath = "$PSScriptRoot\JSON-Files\Master-Policies"
$CustomJsonFilesPath = "$PSScriptRoot\JSON-Files\Custom-Policies"

Write-Host ""
Write-Host "Master JSON Files Path: " -ForegroundColor 'Cyan' -NoNewline
Write-Host $CAGroupSourceIDs -ForegroundColor 'Green'
Write-Host "Custom JSON Files Path: " -ForegroundColor 'Cyan' -NoNewline
Write-Host $CAGroupTargetIDs -ForegroundColor 'Green'


# Import source and target groups from CSV files
Write-Host ""
Write-Host "Importing source and target groups from CSV files..." -ForegroundColor Cyan
$SourceGroups = Import-Csv $CAGroupSourceIDs
$TargetGroups = Import-Csv $CAGroupTargetIDs

# Create a hashtable to map old IDs to new IDs
Write-Host "Creating a hashtable to map old IDs to new IDs..." -ForegroundColor Cyan
$GroupMap = @{}
foreach ($i in 0..($SourceGroups.Count-1)) {
  $GroupMap[$SourceGroups[$i].Id] = $TargetGroups[$i].Id
}


# Fetch all JSON files from the specified path
$JsonFiles = Get-ChildItem -Path "$MasterJsonFilesPath" -Filter "*.json"
$fileCount = $JsonFiles.Count
$currentCount = 0

# Loop through each JSON file for processing
foreach ($JsonFile in $JsonFiles) {
  $currentCount++
  # Provide progress update to the user
  Write-Progress -PercentComplete (($currentCount / $fileCount) * 100) -Status "Processing file $currentCount of $fileCount" -Activity "Updating JSON files"

  Write-Host "Processing file $currentCount of $fileCount $JsonFile" -ForegroundColor Yellow

  # Read and convert JSON content to a PowerShell object
  $JsonContent = Get-Content -Path $JsonFile.FullName -Raw | ConvertFrom-Json

  # Loop through both excludeGroups and includeGroups properties for ID replacements
  foreach ($property in @('excludeGroups', 'includeGroups')) {
      for ($i = 0; $i -lt $JsonContent.conditions.users.$property.Count; $i++) {
          $Group = $JsonContent.conditions.users.$property[$i]
          # Check and replace IDs using the provided hashtable
          if ($GroupMap.ContainsKey($Group)) {
              $JsonContent.conditions.users.$property[$i] = $GroupMap[$Group]
          }
      }
  }

  # Convert the updated PowerShell object back to JSON and save it
  $outvar =  $CustomJsonFilesPath + "\" + "$($JsonFile.Name)"
  $JsonContent | ConvertTo-Json -Depth 4 |  Out-File -FilePath $outvar
  
  Write-Host "Finished processing file $currentCount of $fileCount $JsonFile" -ForegroundColor Gray
}

# Display completion messages to the user
Write-Host ""
Write-Host "Prepared the exported Conditional Access JSON Files with new Group IDs from the Groups of the Target Tenant" -ForegroundColor Green
Write-Host ""
Write-Host "Done." -ForegroundColor Green