﻿$PSScriptRoot = split-path -parent $MyInvocation.MyCommand.Definition
. "$PSScriptRoot\00-Connect-Graph.ps1"

# Declare output path variable with Path and Filename
$CAGroupTargetIDs = Join-Path -Path "$PSScriptRoot\Group-IDs\" -ChildPath "Conditional_Access_Framework_Groups_w_ID_Target.csv"

# Define an array of groups
$groups = @(
    'CA-000-Global-Exclusions'
    'CA-100-Admins'
    'CA-100-Admins-Exclusions'
    'CA-200-Internals'
    'CA-200-Internals-Exclusions'
    'CA-300-Externals'
    'CA-300-Externals-Exclusions'
    'CA-400-Guests'
    'CA-400-Guests-Exclusions'
    'CA-500-GuestAdmins'
    'CA-500-GuestAdmins-Exclusions'
    'CA-600-Microsoft365ServiceAccounts'
    'CA-600-Microsoft365ServiceAccounts-Exclusions'
    'CA-700-AzureServiceAccounts'
    'CA-700-AzureServiceAccounts-Exclusions'
    'CA-800-OnPremisesServiceAccounts'
    'CA-800-OnPremisesServiceAccounts-Exclusions'
    'CA-BreakGlassAccounts'
)

# Loop through the array and create security groups
Write-Host "Creating security groups..." -ForegroundColor Magenta
foreach ($group in $groups) {
    New-MgGroup -DisplayName $group -MailEnabled:$false -MailNickname $group -SecurityEnabled:$true
}


# Get all Microsoft Entra groups with display name starting with 'CA-' 
# Select only the relevant properties
# Export the Output to a CSV File
Write-Host ""
Write-Host "Export Group IDs To CSV Path: " -ForegroundColor 'Cyan' -NoNewline
Write-Host $CAGroupTargetIDs -ForegroundColor 'Green'
Get-MgGroup -Filter "startswith(displayName,'CA-')" | Select-Object DisplayName, Description, Id | Export-Csv -Path $CAGroupTargetIDs


<##
# Delete Existing Groups

$existinggroups = Get-MgGroup | ? {$_.DisplayName -like "CA-*"} 
foreach ($group in $existinggroups) {
    Remove-MgGroup -GroupId $group.id
}
##>
