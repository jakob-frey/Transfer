﻿$PSScriptRoot = split-path -parent $MyInvocation.MyCommand.Definition


# Connect to Microsoft Graph PowerShel
Connect-MgGraph -Scopes "User.Read.All", "Group.ReadWrite.All", "Application.ReadWrite.All", "ConsentRequest.ReadWrite.All", "Directory.ReadWrite.All", "Organization.ReadWrite.All", "Policy.ReadWrite.ConditionalAccess", "Policy.Read.All", ""


# Connection Infos for Microsoft Graph PowerShell SDK Connection
Write-Host "Getting the built-in onmicrosoft.com domain name of the tenant..."
$tenantName = (Get-MgOrganization).VerifiedDomains | Where-Object {$_.IsInitial -eq $true} | Select-Object -ExpandProperty Name
$AppRegistration = (Get-MgContext | Select-Object -ExpandProperty AppName)
$Scopes = (Get-MgContext | Select-Object -ExpandProperty Scopes)
Write-Host "Tenant: $tenantName" -ForegroundColor 'Cyan'
Write-Host "AppRegistration: $AppRegistration" -ForegroundColor 'Magenta'
Write-Host "Scopes: $Scopes" -ForegroundColor 'Cyan'


# Get the current date in MM-dd-yyyy format
$date = Get-Date -Format "MM-dd-yyyy"
