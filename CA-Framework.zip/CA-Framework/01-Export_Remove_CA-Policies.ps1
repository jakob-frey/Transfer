﻿$PSScriptRoot = split-path -parent $MyInvocation.MyCommand.Definition
. "$PSScriptRoot\00-Connect-Graph.ps1"

# Create a folder named after the built-in onmicrosoft.com domain name of the tenant and the date of the export
$CAExportPath = "$PSScriptRoot\Export-Existing-CAs\$tenantName" 
IF (!(Test-Path -Path $CAExportPath)){
    Write-Host ""
    Write-Host "Creating a folder named after the built-in onmicrosoft.com domain name of the tenant and the date of the export..." -ForegroundColor 'Magenta'
    New-Item -ItemType Directory -Path $CAExportPath | Out-Null
    }

# Get all Conditional Access policies
Write-Host "Getting all Conditional Access policies..."
$policies = Get-MgIdentityConditionalAccessPolicy

# Export all Conditional Access policies to separate JSON files with their actual name and display a summary of the exported policies in the shell
Write-Host "Exporting all Conditional Access policies to separate JSON files with their actual name and displaying a summary of the exported policies in the shell..." -ForegroundColor 'Cyan' 
$summary = @()
foreach ($policy in $policies) {
    # Remove id, createdDateTime and modifiedDateTime from policy object
    $policy = $policy | Select-Object -Property * -ExcludeProperty id, createdDateTime, modifiedDateTime
    # Change state from enabled to disabled
    # Don't lock yourself out please use ReportOnly and configure and test the Breakglass Accounts before enabling the policies
    $policy.state = "disabled"
    $name = $policy.DisplayName.Replace('/', '_')
    $file = "$CAExportPath\$name.json"
    Write-Host "Export Policy $name" -ForegroundColor 'Yellow' 
    $policy | ConvertTo-Json -Depth 10 | Out-File -FilePath $file
    $summary += [PSCustomObject]@{
        Name = $policy.DisplayName
        Id = $policy.Id
        File = $file
    }
}

Write-Host "Export to $CAExportPath done..." -ForegroundColor 'Green' 


<##
# Delete All CA Policies
$policies = Get-MgIdentityConditionalAccessPolicy
foreach($policy in $policies) {
    Remove-MgIdentityConditionalAccessPolicy -ConditionalAccessPolicyId $policy.Id
}
##>

