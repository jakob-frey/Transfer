﻿$PSScriptRoot = split-path -parent $MyInvocation.MyCommand.Definition
. "$PSScriptRoot\00-Connect-Graph.ps1"


# Declare output path variable with Path and Filename
$CustomJsonFilesPath = "$PSScriptRoot\JSON-Files\Custom-Policies"
Write-Host "Custom JSON Files Path: " -ForegroundColor 'Cyan' -NoNewline
Write-Host $CustomJsonFilesPath -ForegroundColor 'Green'



# Check for the existence of a particular Service Principal
$servicePrincipal = Get-MgServicePrincipal -Filter "displayName eq 'Microsoft Intune Enrollment'"

# Create the Service Principal if not found
if ($servicePrincipal) {
    Write-Host ""
    Write-Host "Service Principal 'Microsoft Intune Enrollment' exists in the tenant." -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "Service Principal 'Microsoft Intune Enrollment' does not exist in the tenant. Creating now..." -ForegroundColor Yellow

    # Create the Service Principal with the specified AppId
    try {
        New-MgServicePrincipal -AppId "d4ebce55-015a-49b5-a083-c84d1797ae8c"
        Write-Host ""
        Write-Host "Service Principal 'Microsoft Intune Enrollment' created successfully." -ForegroundColor Green
    } catch {
        Write-Host ""
        Write-Host "Failed to create Service Principal 'Microsoft Intune Enrollment'. Error: $_" -ForegroundColor Red
    }
}


# Get all JSON files from the folder
Write-Host ""
Write-Host "Getting all JSON files from the folder..." -ForegroundColor Magenta
$files = Get-ChildItem -Path $CustomJsonFilesPath -Filter *.json


# Getting existing Policies
$policies = (Get-MgIdentityConditionalAccessPolicy).DisplayName


# Loop through each file and import the Conditional Access policy
foreach ($file in $files) {
    Write-Host ""
    Write-Host "Processing file: $($file.Name)..." -ForegroundColor Yellow
    
    $policyname = $($file.Name.Split(".")[0])

    IF ($policies -notcontains $policyname) {
    
        # Read the JSON content from the current file
        $policyJson = Get-Content -Path $file.FullName -Raw


        # Use Invoke-MgGraphRequest to create a new Conditional Access policy
        try {
            #$response = Invoke-MgGraphRequest -Method POST -Uri "https://graph.microsoft.com/v1.0/identity/conditionalAccess/policies" -Body $policyJson -ContentType "application/json"
            $response = New-MgIdentityConditionalAccessPolicy -BodyParameter $policyJson
            Write-Host "Policy imported successfully from $($file.Name)." -ForegroundColor Green
        } catch {
            # Read the StreamContent and convert it to a string
            $errorContent = $_.Exception.Response.Content.ReadAsStringAsync().Result

            # Check if the error details are in JSON format
            if ($errorContent -match "^\s*\{.*\}\s*$") {
                $errorDetails = $errorContent | ConvertFrom-Json
                Write-Error "Failed to import policy from $($file.Name). Error: $($errorDetails.error.message)"
            } else {
                # If not in JSON format, just output the error content as a string
                Write-Error "Failed to import policy from $($file.Name). Error: $errorContent"
            }
        }
    } Else {
        Write-Host "The Policy $($file.Name.Split(".")[0]) already exists" -ForegroundColor Magenta

    }
}
